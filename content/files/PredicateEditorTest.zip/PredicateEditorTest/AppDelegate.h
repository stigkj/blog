//
//  AppDelegate.h
//  PredicateEditorTest
//
//  Created by Vincent on 20-07-09.
//

#import <Cocoa/Cocoa.h>


@interface AppDelegate : NSObject {
	IBOutlet NSWindow *mainWindow;
	IBOutlet NSWindow *sheet;
	
	// This is the predicate that we're going to edit
	NSPredicate *predicate;
}

- (IBAction)openEditor:(id)sender;
- (IBAction)closeEditor:(id)sender;

@end
