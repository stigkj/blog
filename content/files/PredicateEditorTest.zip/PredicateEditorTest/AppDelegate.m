//
//  AppDelegate.m
//  PredicateEditorTest
//
//  Created by Vincent on 20-07-09.
//

#import "AppDelegate.h"

#define DEFAULT_PREDICATE @"(firstname = 'John' AND lastname = 'Doe') " \
                          @"OR birthdate > CAST('01/01/1985', 'NSDate') " \
                          @"OR address.city = 'Chicago' " \
                          @"AND address.street != 'Main Street' " \
                          @"OR address.number > 1000"


@implementation AppDelegate

- (id)init
{
	self = [super init];
	if (self != nil) {
		predicate = [[NSPredicate predicateWithFormat:DEFAULT_PREDICATE] retain];
	}
	return self;
}

- (void)dealloc
{
	[predicate release];
	[super dealloc];
}

- (IBAction)openEditor:(id)sender
{
	[NSApp beginSheet:sheet
	   modalForWindow:mainWindow
		modalDelegate:nil
	   didEndSelector:NULL
		  contextInfo:nil];
}

- (IBAction)closeEditor:(id)sender
{
	[NSApp endSheet:sheet];
	[sheet orderOut:sender];
}

@end
